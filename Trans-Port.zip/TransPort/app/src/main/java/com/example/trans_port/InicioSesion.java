package com.example.trans_port;

import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import java.util.HashMap;
import java.util.Map;

public class InicioSesion extends AppCompatActivity {

    EditText etinUsuario, etinContraseña;
    Button btnIngresar, btnSalir;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inicio_sesion);

        // Configuración edge-to-edge
        ViewCompat.setOnApplyWindowInsetsListener(getWindow().getDecorView(), (view, insets) -> {
            Insets systemBarsInsets = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            view.setPadding(systemBarsInsets.left, systemBarsInsets.top, systemBarsInsets.right, systemBarsInsets.bottom);
            return WindowInsetsCompat.CONSUMED;
        });

        etinUsuario = findViewById(R.id.etinUsuario);
        etinContraseña = findViewById(R.id.etinContraseña);
        btnIngresar = findViewById(R.id.btnIngresar);
        btnSalir = findViewById(R.id.btnSalir);

        // Acción para el botón "Ingresar"
        btnIngresar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                iniciarSesion();
            }
        });

        // Acción para el botón "Salir"
        btnSalir.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getApplicationContext(), Login.class);
                startActivity(i);
            }
        });
    }

    private void iniciarSesion() {
        String p_usuario = etinUsuario.getText().toString().trim();
        String p_contraseña = etinContraseña.getText().toString().trim();

        if (p_usuario.isEmpty()) {
            Toast.makeText(this, "Ingrese usuario", Toast.LENGTH_SHORT).show();
        } else if (p_contraseña.isEmpty()) {
            Toast.makeText(this, "Ingrese contraseña", Toast.LENGTH_SHORT).show();
        } else {
            ProgressDialog progressDialog = new ProgressDialog(this);
            progressDialog.setMessage("Iniciando sesión...");
            progressDialog.show();

            if(p_usuario.equals("admin") && p_contraseña.equals("admin")){
                Toast.makeText(InicioSesion.this, "Inicio de sesión exitoso", Toast.LENGTH_SHORT).show();
                // Navegar a la actividad de usuario
                startActivity(new Intent(getApplicationContext(), inicioAdministrador.class));
                finish();
            }
            else {


                // Cambiar la URL al archivo PHP de validación
                StringRequest request = new StringRequest(Request.Method.POST, "http://192.168.0.5:80/crud_transport/validarusuario_.php",
                        new Response.Listener<String>() {
                            @Override
                            public void onResponse(String response) {
                                progressDialog.dismiss();
                                if (response.trim().equals("success")) {
                                    Toast.makeText(InicioSesion.this, "Inicio de sesión exitoso", Toast.LENGTH_SHORT).show();
                                    // Navegar a la actividad de usuario
                                    startActivity(new Intent(getApplicationContext(), inicioUsuario.class));
                                    finish();
                                } else {
                                    Toast.makeText(InicioSesion.this, "Usuario o contraseña incorrectos", Toast.LENGTH_SHORT).show();
                                }
                            }
                        },
                        new Response.ErrorListener() {
                            @Override
                            public void onErrorResponse(VolleyError error) {
                                progressDialog.dismiss();
                                Toast.makeText(InicioSesion.this, "Error: " + error.getMessage(), Toast.LENGTH_SHORT).show();
                            }
                        }) {
                    @Override
                    protected Map<String, String> getParams() throws AuthFailureError {
                        Map<String, String> params = new HashMap<>();
                        params.put("usuario", p_usuario);
                        params.put("contraseña", p_contraseña);
                        return params;
                    }
                };
                RequestQueue requestQueue = Volley.newRequestQueue(InicioSesion.this);
                requestQueue.add(request);
            }
        }
    }

    private void confirmarSalida() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage("¿Desea salir de la aplicación?");
        builder.setPositiveButton("Sí", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                finish(); // Cierra la actividad y sale de la app
            }
        });
        builder.setNegativeButton("No", null);
        builder.show();
    }
}
