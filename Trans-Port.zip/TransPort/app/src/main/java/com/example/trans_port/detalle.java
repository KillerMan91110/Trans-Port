package com.example.trans_port;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.ImageRequest;
import com.android.volley.toolbox.Volley;

public class detalle extends AppCompatActivity{

    TextView detalleNom, detalleApe, detalleCic, detalleDes;
    ImageView detalleImagen;
    Button btnUbicacion;


    private RequestQueue rq;
    int position;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detalle);


        detalleNom=findViewById(R.id.detalleNom);
        detalleApe=findViewById(R.id.detalleApe);
        detalleCic=findViewById(R.id.detalleCic);
        detalleDes=findViewById(R.id.detalleDes);
        detalleImagen = findViewById(R.id.detalleImage);
        rq= Volley.newRequestQueue(this);
        btnUbicacion = findViewById(R.id.btnUbi);

        btnUbicacion.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getApplicationContext(), usuarioUbicacion.class);
                startActivity(i);
            }
        });

        Intent intent=getIntent();
        position=intent.getExtras().getInt("position");


        detalleNom.setText(usuarioPaquetes.listaUsuarios.get(position).getOrigen());
        detalleApe.setText(usuarioPaquetes.listaUsuarios.get(position).getProducto());
        detalleCic.setText(usuarioPaquetes.listaUsuarios.get(position).getDestino());
        detalleDes.setText(usuarioPaquetes.listaUsuarios.get(position).getDescripcion());
        cargarImagenUrl(usuarioPaquetes.listaUsuarios.get(position).getUrlimagen());


    }

    private void cargarImagenUrl(String url) {
        ImageRequest request = new ImageRequest(url,
                new Response.Listener<Bitmap>() {
                    @Override
                    public void onResponse(Bitmap bitmap) {
                        detalleImagen.setImageBitmap(bitmap);
                    }
                }, 0, 0, ImageView.ScaleType.CENTER_CROP, null,
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError volleyError) {
                        // Manejar errores de carga de imagen, si es necesario
                    }
                });
        // Agregar la solicitud a la cola de solicitudes de Volley
        rq.add(request);
    }

}
