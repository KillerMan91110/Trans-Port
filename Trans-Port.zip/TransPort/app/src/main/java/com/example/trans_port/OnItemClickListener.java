package com.example.trans_port;

public interface OnItemClickListener {
    void onItemClick(Envios estudiante);
}