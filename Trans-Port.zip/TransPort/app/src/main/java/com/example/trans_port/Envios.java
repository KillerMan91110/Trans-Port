package com.example.trans_port;

public class Envios {
    String id;
    String origen;
    String destino;
    String producto;
    String descripcion;
    String urlimagen;

    public Envios(String id, String origen, String destino, String producto, String descripcion, String urlimagen) {
        this.id = id;
        this.origen = origen;
        this.destino = destino;
        this.producto = producto;
        this.descripcion = descripcion;
        this.urlimagen = urlimagen;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getOrigen() {
        return origen;
    }

    public void setOrigen(String origen) {
        this.origen = origen;
    }

    public String getDestino() {
        return destino;
    }

    public void setDestino(String destino) {
        this.destino = destino;
    }

    public String getProducto() {
        return producto;
    }

    public void setProducto(String producto) {
        this.producto = producto;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public String getUrlimagen() {
        return urlimagen;
    }

    public void setUrlimagen(String urlimagen) {
        this.urlimagen = urlimagen;
    }
}
